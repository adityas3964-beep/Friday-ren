package com.jarvis.assistant

import com.jarvis.assistant.command.Cmd
import com.jarvis.assistant.command.CommandParser
import com.jarvis.assistant.command.WakeMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

class CommandParserTest {
    @Test fun opensApp() {
        assertEquals(Cmd.OpenApp("youtube"), CommandParser.parse("YouTube khol"))
        assertEquals(Cmd.OpenApp("whatsapp"), CommandParser.parse("open whatsapp"))
    }
    @Test fun youtubeSearch() {
        assertEquals(Cmd.YouTubeSearch("arijit singh songs"), CommandParser.parse("youtube par arijit singh songs"))
    }
    @Test fun webSearch() {
        assertEquals(Cmd.WebSearch("weather today"), CommandParser.parse("search weather today"))
        assertTrue(CommandParser.parse("search") is Cmd.MissingArg)
    }
    @Test fun whatsapp() {
        assertEquals(Cmd.WhatsApp("rahul", "hello kaise ho"), CommandParser.parse("rahul ko message bhejo hello kaise ho"))
        assertEquals(Cmd.WhatsApp("rahul", "hi"), CommandParser.parse("send message to rahul hi"))
    }
    @Test fun settingsTimeNames() {
        assertEquals(Cmd.OpenSettings("wifi"), CommandParser.parse("wifi settings kholo"))
        assertEquals(Cmd.TellTime, CommandParser.parse("abhi time kya hua"))
        assertEquals(Cmd.AskName, CommandParser.parse("tumhara naam kya hai"))
        assertEquals(Cmd.AskUserName, CommandParser.parse("mera naam kya hai"))
    }
    @Test fun confirmations() {
        assertEquals(Cmd.Yes, CommandParser.parse("haan"))
        assertEquals(Cmd.No, CommandParser.parse("nahi"))
    }
    @Test fun wake() {
        assertTrue(WakeMatcher.matches("hey jarvis", "hey jarvis"))
        assertTrue(WakeMatcher.matches("hello jar vis", "hey jarvis"))
        assertFalse(WakeMatcher.matches("good morning", "hey jarvis"))
    }
}
