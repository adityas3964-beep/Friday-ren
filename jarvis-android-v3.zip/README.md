# J.A.R.V.I.S — native Android voice assistant (Kotlin + Jetpack Compose)

> **Honest status:** this source was written without being compiled or run. Treat the first GitHub Actions build as the first test. If it fails, open the log and send me the error lines.

## Versions
minSdk 26 · compileSdk/targetSdk 34 · AGP 8.5.2 · Gradle 8.7 · Kotlin 1.9.24 · Compose compiler 1.5.14 · JDK 17

## Build from your phone (GitHub)
1. github.com → **New repository** (private is fine).

3. Commit. Open **Actions → Build JARVIS debug APK → Run workflow**.
4. If it fails, open the run → failed step → copy the red `error:` lines.
5. On success, open the run → **Artifacts → jarvis-debug-apk**, download, unzip, install the APK (allow "install unknown apps").

Local command: `gradle :app:testDebugUnitTest :app:assembleDebug` (Gradle 8.7, JDK 17). No wrapper is included; run `gradle wrapper --gradle-version 8.7` once if you want one.

## First run
1. Open **SYSTEM → Voice models** and download the English model (and Hindi if wanted). Download URLs are from alphacephei.com/vosk/models and were **not verified** here; manual install instructions are shown in that panel.
2. Grant Microphone (prompted on START), Contacts (WhatsApp names), **Display over other apps** (required to open apps from the background on Android 10+).
3. Enable **Accessibility** (for WhatsApp Send, reel swipe, Back/Home) and optionally **Device Admin** (lock).
4. **PROFILE**: set your name.
5. START LISTENING, say "Hey Jarvis", then a command. PUSH TO TALK skips the wake word.

## Honest feature checklist
| Feature | Status |
|---|---|
| Splash with real checks, HUD dashboard, panels | Written, unverified |
| Push-to-talk, Vosk recognition, TTS, state machine | Written, unverified |
| Wake phrase | Partial: continuous Vosk recognition matched to text (not a dedicated engine; battery heavy) |
| Hindi recognition | Depends on the downloaded Hindi model; accuracy unverified |
| Hinglish | Normalisation layer + English-India model; expect errors with Hindi words |
| Open apps / search / YouTube / settings screens | Written, unverified |
| WhatsApp message | Resolves contact, asks to confirm, opens chat, taps Send via Accessibility. Cannot verify delivery |
| Phone lock | Device Admin force-lock, or Accessibility lock (Android 9+) |
| Toggle Wi-Fi/Bluetooth | Not possible on modern Android; opens the settings screen instead |
| Optional AI | OpenAI-compatible endpoint, key encrypted with Android Keystore; no on-device LLM bundled; off by default |
| Waveform / core animation | Driven by assistant state, not microphone amplitude |
| Background reliability | Foreground service with Stop action; many OEMs kill it — set battery to Unrestricted |

## Privacy notes
Accessibility is limited by `packageNames` to WhatsApp, reads nothing passively, stores nothing. `usesCleartextTraffic` is on only so a LAN AI server over http:// works.
