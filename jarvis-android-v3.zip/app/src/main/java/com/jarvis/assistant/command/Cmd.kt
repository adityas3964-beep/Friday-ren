package com.jarvis.assistant.command

/** Explicit intents produced by [CommandParser]. */
sealed class Cmd {
    data class OpenApp(val name: String) : Cmd()
    data class WebSearch(val query: String) : Cmd()
    data class YouTubeSearch(val query: String) : Cmd()
    data class OpenSettings(val kind: String) : Cmd()
    data class WhatsApp(val recipient: String, val text: String) : Cmd()
    data class Swipe(val up: Boolean) : Cmd()
    data class MissingArg(val question: String) : Cmd()
    data class Chat(val text: String) : Cmd()
    data class Unknown(val raw: String) : Cmd()
    object Greeting : Cmd()
    object TellTime : Cmd()
    object TellDate : Cmd()
    object AskName : Cmd()
    object AskUserName : Cmd()
    object Lock : Cmd()
    object Back : Cmd()
    object Home : Cmd()
    object Stop : Cmd()
    object Yes : Cmd()
    object No : Cmd()
    object Thanks : Cmd()
    object HowAreYou : Cmd()
}
