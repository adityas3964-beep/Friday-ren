package com.jarvis.assistant.command

data class CommandResult(
    val success: Boolean,
    val message: String,
    val requiresConfirmation: Boolean = false,
    val followUp: String? = null,
    val source: String = "LOCAL",
    val stopSession: Boolean = false
)

class ConfirmationManager {
    @Volatile private var pending: (suspend () -> CommandResult)? = null
    val hasPending: Boolean get() = pending != null
    fun set(action: suspend () -> CommandResult) { pending = action }
    fun take(): (suspend () -> CommandResult)? { val p = pending; pending = null; return p }
    fun clear(): Boolean { val had = pending != null; pending = null; return had }
}
