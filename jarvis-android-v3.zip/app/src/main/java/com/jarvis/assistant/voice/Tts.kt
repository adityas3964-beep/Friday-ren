package com.jarvis.assistant.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.jarvis.assistant.data.AssistantState
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** Android TextToSpeech wrapper. The callback always fires exactly once (done, error, or watchdog timeout). */
class Tts(context: Context) {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var ready = false
    private var engine: TextToSpeech? = null
    private var current: (() -> Unit)? = null
    private var finished = AtomicBoolean(true)
    private var watchdog: Runnable? = null

    init {
        engine = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (!ready) AssistantState.error.value = "Text-to-speech initialise nahi hua"
            else engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { main.post { finish() } }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { main.post { finish() } }
            })
        }
    }

    fun speak(text: String, lang: String, done: () -> Unit) {
        val e = engine
        if (!ready || e == null) { done(); return }
        val primary = if (lang == "hi") Locale("hi", "IN") else Locale("en", "IN")
        var r = e.setLanguage(primary)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            AssistantState.error.value = "${primary.toLanguageTag()} voice data missing; English use ho raha hai"
            r = e.setLanguage(Locale.ENGLISH)
        }
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) { done(); return }
        cancelCurrent()
        finished = AtomicBoolean(false)
        current = done
        val w = Runnable { finish() }
        watchdog = w
        main.postDelayed(w, (4000L + text.length * 120L).coerceAtMost(30000L))
        val res = e.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.nanoTime()}")
        if (res != TextToSpeech.SUCCESS) finish()
    }

    private fun finish() {
        if (!finished.compareAndSet(false, true)) return
        watchdog?.let { main.removeCallbacks(it) }
        val cb = current
        current = null
        cb?.invoke()
    }

    private fun cancelCurrent() {
        watchdog?.let { main.removeCallbacks(it) }
        current = null
        finished.set(true)
    }

    fun stop() {
        cancelCurrent()
        try { engine?.stop() } catch (_: Exception) {}
    }

    fun shutdown() {
        stop()
        try { engine?.shutdown() } catch (_: Exception) {}
        engine = null
        ready = false
    }
}
