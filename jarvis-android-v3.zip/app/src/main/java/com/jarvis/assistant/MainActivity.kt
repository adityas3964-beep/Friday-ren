package com.jarvis.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.command.PermissionManager
import com.jarvis.assistant.data.AssistantState
import com.jarvis.assistant.ui.*
import com.jarvis.assistant.voice.VoskEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisTheme { JarvisRoot() } }
    }

    override fun onStart() { super.onStart(); AssistantState.appForeground = true }
    override fun onStop() { AssistantState.appForeground = false; super.onStop() }
}

@Composable
fun JarvisRoot() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as JarvisApp
    var booted by rememberSaveable { mutableStateOf(false) }
    var step by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("INITIALIZING SYSTEM") }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        if (booted) return@LaunchedEffect
        // Each boot step performs a real check; the short delay is only so the status text is readable.
        val steps: List<Pair<String, () -> Boolean>> = listOf(
            "INITIALIZING SYSTEM" to { app.settings.prefs.value; app.history.items.value; true },
            "LOADING VOICE ENGINE" to { VoskEngine.hasModel(ctx, app.settings.prefs.value.recogLang) },
            "CHECKING PERMISSIONS" to { PermissionManager.mic(ctx) },
            "CHECKING SERVICES" to { PermissionManager.accessibility(ctx) },
            "SYSTEM READY" to { true }
        )
        for ((i, s) in steps.withIndex()) {
            status = s.first
            val ok = withContext(Dispatchers.IO) { s.second() }
            if (!ok && i in 1..3) status = s.first + " — ATTENTION"
            step = i + 1
            delay(450)
        }
        booted = true
    }

    if (!booted) { SplashScreen(status, step, 5); return }

    Column(Modifier.fillMaxSize().background(Hud.Bg).systemBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> Dashboard()
                1 -> HistoryPanel()
                2 -> ProfilePanel()
                else -> SystemPanel()
            }
        }
        Row(Modifier.fillMaxWidth().background(Hud.Panel)) {
            listOf("HOME", "LOG", "PROFILE", "SYSTEM").forEachIndexed { i, label ->
                Box(
                    Modifier.weight(1f).defaultMinSize(minHeight = 56.dp)
                        .clickable(role = Role.Tab) { tab = i },
                    contentAlignment = Alignment.Center
                ) { HudText(label, size = 12.sp, color = if (tab == i) Hud.Cyan else Hud.Sub, spacing = 1.5.sp) }
            }
        }
    }
}
