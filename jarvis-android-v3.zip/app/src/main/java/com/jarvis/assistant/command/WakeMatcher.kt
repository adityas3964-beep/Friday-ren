package com.jarvis.assistant.command

/**
 * Text-based wake phrase matching on top of continuous Vosk recognition.
 * This is NOT a dedicated wake-word engine: it is ordinary speech recognition whose output is compared to the phrase.
 */
object WakeMatcher {
    private val jarvisAliases = listOf("jarvis", "jar vis", "jarvas", "jarvish", "jarves", "jarwis", "javis", "जार्विस", "जारविस")

    fun matches(text: String, phrase: String): Boolean {
        val t = text.lowercase().trim()
        if (t.isEmpty()) return false
        val p = phrase.lowercase().trim().ifEmpty { "hey jarvis" }
        if (t.contains(p)) return true
        val key = p.split(" ").last()
        if (key == "jarvis") return jarvisAliases.any { t.contains(it) }
        return key.length >= 4 && t.contains(key)
    }
}
