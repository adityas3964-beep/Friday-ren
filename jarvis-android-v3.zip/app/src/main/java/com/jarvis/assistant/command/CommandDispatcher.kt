package com.jarvis.assistant.command

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.accessibility.JarvisAccessibilityService
import com.jarvis.assistant.ai.AiClient
import com.jarvis.assistant.data.AssistantState
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Maps parsed intents to real Android actions. Never reports success for an action that did not run. */
class CommandDispatcher(private val ctx: Context, private val app: JarvisApp) {
    val confirmation = ConfirmationManager()

    private val knownPackages = mapOf(
        "youtube" to "com.google.android.youtube", "whatsapp" to "com.whatsapp", "instagram" to "com.instagram.android",
        "chrome" to "com.android.chrome", "gmail" to "com.google.android.gm", "maps" to "com.google.android.apps.maps",
        "telegram" to "org.telegram.messenger", "spotify" to "com.spotify.music", "facebook" to "com.facebook.katana"
    )

    suspend fun dispatch(cmd: Cmd, turns: List<Pair<String, String>>): CommandResult {
        val p = app.settings.prefs.value
        val who = p.userName.ifBlank { "sir" }
        if (cmd !is Cmd.Yes && cmd !is Cmd.No) confirmation.clear()
        return when (cmd) {
            is Cmd.Yes -> confirmation.take()?.invoke()
                ?: CommandResult(false, "Kis baat ke liye haan, $who? Pehle koi command boliye.")
            is Cmd.No -> { confirmation.clear(); CommandResult(true, "Theek hai $who, cancel kar diya.") }
            is Cmd.Greeting -> CommandResult(true, "Haan $who, boliye. Main sun raha hoon.")
            is Cmd.Thanks -> CommandResult(true, "Koi baat nahi $who.")
            is Cmd.HowAreYou -> CommandResult(true, "Main theek hoon $who. Aap bataiye, kya karun?")
            is Cmd.AskName -> CommandResult(true, "Mera naam JARVIS hai.")
            is Cmd.AskUserName ->
                if (p.userName.isBlank()) CommandResult(true, "Aapne abhi apna naam nahi bataya. Profile mein naam daal dijiye.")
                else CommandResult(true, "Aapka naam ${p.userName} hai.")
            is Cmd.TellTime -> CommandResult(true, "Abhi samay ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())} hai.")
            is Cmd.TellDate -> CommandResult(true, "Aaj ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())} hai.")
            is Cmd.Stop -> CommandResult(true, "Theek hai $who, main band ho raha hoon.", stopSession = true)
            is Cmd.OpenApp -> openApp(cmd.name, who)
            is Cmd.WebSearch -> launchUri("https://www.google.com/search?q=${Uri.encode(cmd.query)}", null,
                "Bilkul $who, '${cmd.query}' search kar raha hoon.", who)
            is Cmd.YouTubeSearch -> launchUri("https://www.youtube.com/results?search_query=${Uri.encode(cmd.query)}",
                "com.google.android.youtube", "Bilkul $who, YouTube par '${cmd.query}' dhundh raha hoon.", who)
            is Cmd.OpenSettings -> openSettings(cmd.kind, who)
            is Cmd.Swipe -> withAccessibility(who) { it.swipe(cmd.up) }
                .let { if (it.success) CommandResult(true, if (cmd.up) "Agla video." else "Pichla video.") else it }
            is Cmd.Back -> withAccessibility(who) { it.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK) }
                .let { if (it.success) CommandResult(true, "Peeche aa gaya.") else it }
            is Cmd.Home -> withAccessibility(who) { it.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME) }
                .let { if (it.success) CommandResult(true, "Home screen par aa gaya.") else it }
            is Cmd.Lock -> lockPhone(who)
            is Cmd.WhatsApp -> prepareWhatsApp(cmd.recipient, cmd.text, who)
            is Cmd.MissingArg -> CommandResult(false, cmd.question, followUp = cmd.question)
            is Cmd.Chat -> chat(cmd.text, turns, p.aiEnabled, p.aiEndpoint, p.aiModel, p.userName, who)
            is Cmd.Unknown -> CommandResult(false, "Samajh nahi aaya $who. Aap 'YouTube khol' ya 'samay kya hua' jaisa bol sakte hain.")
        }
    }

    // ---- launching ----

    /** Android 10+ blocks activity starts from the background unless the app may draw over other apps. */
    private fun canLaunch() = AssistantState.appForeground || Settings.canDrawOverlays(ctx)

    private fun backgroundBlocked(who: String) = CommandResult(false,
        "$who, background se app kholne ke liye 'Display over other apps' permission chahiye. Settings panel mein dijiye.")

    private fun start(i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    private fun launchUri(url: String, pkg: String?, okMsg: String, who: String): CommandResult {
        if (!canLaunch()) return backgroundBlocked(who)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        if (pkg != null) {
            i.setPackage(pkg)
            if (start(i)) return CommandResult(true, okMsg)
            i.setPackage(null)
        }
        return if (start(i)) CommandResult(true, okMsg) else CommandResult(false, "Ye kholne ke liye koi app nahi mili.")
    }

    private fun openApp(name: String, who: String): CommandResult {
        if (!canLaunch()) return backgroundBlocked(who)
        val key = closestKnown(name.lowercase().trim())
        if (key == "settings" || key == "setting") {
            return if (start(Intent(Settings.ACTION_SETTINGS))) CommandResult(true, "Bilkul $who, Settings khol raha hoon.")
            else CommandResult(false, "Settings nahi khul paayi.")
        }
        val pm = ctx.packageManager
        val pkg: String? = knownPackages[key]?.takeIf { pm.getLaunchIntentForPackage(it) != null } ?: run {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(main, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            val exact = apps.filter { it.first.equals(name, true) }.distinctBy { it.second }
            val cand = if (exact.isNotEmpty()) exact else apps.filter { it.first.contains(name, true) }.distinctBy { it.second }
            when {
                cand.size == 1 -> cand[0].second
                cand.size > 1 -> return CommandResult(false,
                    "Kaun sa kholun $who: ${cand.take(3).joinToString(", ") { it.first }}? Poora naam boliye.")
                else -> null
            }
        }
        if (pkg == null) return CommandResult(false, "$who, '$name' naam ki app mujhe is phone mein nahi mili.")
        val li = pm.getLaunchIntentForPackage(pkg) ?: return CommandResult(false, "'$name' abhi nahi khul sakti.")
        return if (start(li)) CommandResult(true, "Bilkul $who, $name khol raha hoon.")
        else CommandResult(false, "'$name' kholne mein dikkat aayi.")
    }

    /** Fixes small misrecognitions ("youtub", "instagam") by matching to a known app name within edit distance 2. */
    private fun closestKnown(name: String): String {
        if (name in knownPackages || name.length < 4) return name
        val best = knownPackages.keys.minByOrNull { editDistance(it, name) } ?: return name
        return if (editDistance(best, name) <= 2) best else name
    }

    private fun editDistance(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    private fun openSettings(kind: String, who: String): CommandResult {
        if (!canLaunch()) return backgroundBlocked(who)
        val (action, label) = when (kind) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS to "Wi-Fi"
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS to "Bluetooth"
            "display" -> Settings.ACTION_DISPLAY_SETTINGS to "Display"
            "sound" -> Settings.ACTION_SOUND_SETTINGS to "Sound"
            else -> Settings.ACTION_ACCESSIBILITY_SETTINGS to "Accessibility"
        }
        return if (start(Intent(action)))
            CommandResult(true, "$label settings khol raha hoon $who. Android seedha on/off karne nahi deta, wahan se aap kar sakte hain.")
        else CommandResult(false, "$label settings nahi khul paayi.")
    }

    // ---- accessibility-backed actions ----

    private fun withAccessibility(who: String, block: (JarvisAccessibilityService) -> Boolean): CommandResult {
        val s = JarvisAccessibilityService.instance
            ?: return CommandResult(false, "$who, Accessibility service band hai. Dashboard se usse chalu kijiye.")
        return if (block(s)) CommandResult(true, "Ho gaya.") else CommandResult(false, "Ye action abhi nahi ho paaya.")
    }

    private fun lockPhone(who: String): CommandResult {
        if (PermissionManager.adminActive(ctx)) {
            return try {
                (ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).lockNow()
                CommandResult(true, "Phone lock kar diya $who.")
            } catch (e: Exception) { CommandResult(false, "Lock nahi ho paaya: ${e.message}") }
        }
        val s = JarvisAccessibilityService.instance
        if (s != null && s.lockScreen()) return CommandResult(true, "Phone lock kar diya $who.")
        return CommandResult(false, "$who, lock ke liye Device Admin chalu karna hoga (Settings panel > Device Admin).")
    }

    // ---- WhatsApp ----

    private fun lookupContact(name: String): List<Pair<String, String>> {
        val out = LinkedHashMap<String, String>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { c ->
            while (c.moveToNext()) out.putIfAbsent(c.getString(0), c.getString(1))
        }
        return out.toList()
    }

    private fun prepareWhatsApp(recipient: String, text: String, who: String): CommandResult {
        if (!PermissionManager.contacts(ctx))
            return CommandResult(false, "$who, contact dhundhne ke liye Contacts permission chahiye. Settings panel mein dijiye.")
        val matches = lookupContact(recipient)
        if (matches.isEmpty()) return CommandResult(false, "'$recipient' naam ka contact nahi mila.")
        val exact = matches.filter { it.first.equals(recipient, true) }
        val chosen = when {
            exact.size == 1 -> exact[0]
            matches.size == 1 -> matches[0]
            else -> return CommandResult(false,
                "Kaun sa $recipient $who: ${matches.take(3).joinToString(", ") { it.first }}? Poora naam boliye.")
        }
        var digits = chosen.second.filter { it.isDigit() || it == '+' }.removePrefix("+")
        if (digits.length == 10) digits = "91$digits"   // assumes India (+91) for bare 10-digit numbers
        val msg = "$who, main ${chosen.first} ko WhatsApp par ye message bhejne wala hoon: $text. Bhej doon?"
        confirmation.set {
            if (!canLaunch()) return@set backgroundBlocked(who)
            val uri = Uri.parse("https://wa.me/$digits?text=${Uri.encode(text)}")
            val pkgs = listOf("com.whatsapp", "com.whatsapp.w4b")
            val opened = pkgs.any { start(Intent(Intent.ACTION_VIEW, uri).setPackage(it)) }
            if (!opened) return@set CommandResult(false, "WhatsApp nahi khul paaya. Kya WhatsApp install hai?")
            val svc = { JarvisAccessibilityService.instance }
            if (svc() == null) CommandResult(true,
                "Message WhatsApp mein tayyar hai $who, par Accessibility service band hai, isliye Send aap khud dabaiye.")
            else {
                var clicked = false
                repeat(12) { if (!clicked) { delay(500); clicked = svc()?.clickWhatsAppSend() == true } }
                if (clicked) CommandResult(true, "Send button dabaya $who. Delivery main verify nahi kar sakta.")
                else CommandResult(true, "Message tayyar hai par Send button nahi mila $who. Aap khud Send dabaiye.")
            }
        }
        return CommandResult(true, msg, requiresConfirmation = true)
    }

    // ---- AI ----

    private suspend fun chat(
        text: String, turns: List<Pair<String, String>>, enabled: Boolean, endpoint: String,
        model: String, userName: String, who: String
    ): CommandResult {
        if (!enabled || endpoint.isBlank())
            return CommandResult(false, "Ye mujhe samajh nahi aaya $who. AI configure nahi hai, isliye main sirf local commands kar sakta hoon.")
        val r = AiClient.chat(endpoint, app.settings.apiKey(), model, userName, turns, text)
        return r.fold(
            onSuccess = { AssistantState.aiStatus.value = "ONLINE"; CommandResult(true, it, source = "AI") },
            onFailure = { AssistantState.aiStatus.value = "ERROR"; CommandResult(false, "AI se connect nahi ho paaya: ${it.message}") }
        )
    }
}
